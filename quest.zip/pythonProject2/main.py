from Window import *



win = Window(800,600, "Python Quest")
win.draw_widjets()
win.run()
