import tkinter

from tkinter import *
from PIL import Image as pilImg
from PIL import ImageTk


# Создание окна
class Window:

    def __init__(self, width, height, title="My Window", resizable=(False, False), icon=r"resourses/python.ico"):
        self.root = Tk()
        self.root.title(title)
        self.root.geometry(f"{width}x{height}+200+200")
        self.root.resizable(resizable[0], resizable[1])

        if icon is not None:
            self.root.iconbitmap(icon)

        img = pilImg.open(r"resourses/python.ico")
        img.resize((20, 20))

        self.photo_img = ImageTk.PhotoImage(img)
        self.redy = False

    def run(self):
        self.root.mainloop()

    def draw_widjets(self):
        self.root.image = PhotoImage(file=r"resourses/tower.png")
        self.root.bg_logo = Label(self.root, image=self.root.image)
        self.root.bg_logo.grid(row=0, column=0)

        Button(self.root, text="1 Этап", width=10, height=2, bg="green", command=self.stage_1).place(rely=.32, relx=.47)
        Label(self.root, text="Второй этап", width=15, height=2, bg="red").place(rely=.43, relx=.45)
        # Button(self.root, text="2 Этап", width=15, height=2, bg="green", command=self.stage_2).place(rely=.43, relx=.45, )
        Label(self.root, text="Третий этап", width=20, height=2, bg="red").place(rely=.55, relx=.42)
        Label(self.root, text="Четверый этап", width=25, height=2, bg="red").place(rely=.68, relx=.40)
        Label(self.root, text="Пятый этап", width=30, height=2, bg="red").place(rely=.86, relx=.38)
        #Button(self.root, text="3 Этап", width=20, height=2, bg="green", command=self.stage_3).place(rely=.55, relx=.42)
        #self.stage4 = Button(self.root, text="4 Этап", width=25, height=2, bg="green", command=self.stage_4).place(rely=.68, relx=.40)
        #self.stage5 = Button(self.root, text="5 Этап", width=30, height=3, bg="green", command=self.stage_5).place(rely=.86, relx=.38)

        Button(self.root, text='Выйти', width=30, command=self.root.destroy, bg='yellow').place(relx=.72, rely=0)

    # Первый этам игры

    def stage_1(self):
        self.top_win1 = tkinter.Toplevel(width=800, height=600)
        self.top_win1.geometry((f"{600}x{600}+200+200"))
        self.top_win1.focus_set()
        self.top_win1.grab_set()

        self.top_win1.image = PhotoImage(file=r"resourses/1этап/комнаты.png")
        self.top_win1.bg_logo = Label(self.top_win1, image=self.top_win1.image)
        self.top_win1.bg_logo.grid(row=0, column=0)

        Button(self.top_win1, text="Выйти", command=self.top_win1.destroy, bg='yellow').place(rely=.95, relx=.89)

        Label(self.top_win1, text="Print и input", width=16, height=2, bg="red").place(rely=.05, relx=.79)
        Label(self.top_win1, text="Целочисленная \nарифметика", width=14, height=2, bg="red").place(rely=.65, relx=.71)

        Button(self.top_win1, text="Установка Python", command=lambda: [self.chapter1_stage1(), self.go_to_ch2()]).place(rely=.15, relx=.01)

    def chapter1_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy).pack(anchor=NE)

        self.image2 = PhotoImage(file=r"resourses/1этап/Установка пайтон.png")

        self.image = PhotoImage(file=r"resourses/1этап/установка пайтон1.png")

        Label(self.top1, image=self.image).place(rely=0, relx=0)
        Label(self.top1, image=self.image2).place(rely=.2)
        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.downloadPycharm()]).place(rely=.8, relx=.45)

    def downloadPycharm(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/1этап/pycharm_.png")
        self.image2 = PhotoImage(file=r"resourses/1этап/Установка Pycharm.png")
        Label(self.top1, image=self.image2).place(relx=0, rely=0)
        Label(self.top1, image=self.image).place(rely=.3)
        Button(self.top1, text="Усвоить урок", bg="green", command=self.top1.destroy).place(rely=.0, relx=.45)

    def go_to_ch2(self):
        Button(self.top_win1, text="Команды print и input", bg="green", command=lambda: [self.chapter2_stage1(), self.go_to_ch3()], width=16,
               height=2, wraplength=0).place(rely=.05, relx=.79)

    def go_to_ch3(self):
        Button(self.top_win1, text="Целочисленная \nарифметика", bg="green", command=self.chapter3_stage1, width=14, height=2).place(rely=.65,
                                                                                                                                     relx=.71)

    def chapter2_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        Button(self.top1, text="Вернуться назад", command=self.top1.destroy).place(relx=.9, rely=85)

        Button(self.top1, text="Команда print", command=self.chapterPrint_stage1).place(relx=.48, rely=.4)
        Button(self.top1, text="Команда input", command=self.chapterInput_stage1).place(relx=.48, rely=.6)
        Button(self.top1, text="Вернуться в лобби", command=self.top1.destroy, bg="yellow").place(relx=.8, rely=.9)

    def chapterPrint_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/2этап/print1.png")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy).pack(anchor=NE)
        Button(self.top1, text="далее", command=lambda: [self.top1.destroy(), self.chapterPrint2_stage1()]).pack(anchor=S)

    def chapterPrint2_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/2этап/print2.png")
        Label(self.top1, image=self.image).pack(anchor=CENTER)

        Button(self.top1, text="Вернуться в комнату", command=self.top1.destroy).pack(anchor=S)

    def chapterInput_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/2этап/input1.PNG")

        Button(self.top1, text="Вернуться назад", command=self.top1.destroy).pack(anchor=SE)
        Label(self.top1, image=self.image).pack(anchor=CENTER)

    def chapter3_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/3этап/ца1.PNG")

        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chapter3_2_stage1()]).pack(anchor=S)
        Label(self.top1, image=self.image).pack(anchor=CENTER)

        # Button(self.top1,text="Перейти к заданиям", command=lambda: [self.top1.destroy(), self.stage1_quest()]).pack()

    def chapter3_2_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/3этап/ца2.PNG")

        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chapter3_3_stage1()]).pack(anchor=S)
        Label(self.top1, image=self.image).pack(anchor=CENTER)

    def chapter3_3_stage1(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file=r"resourses/3этап/ца3.PNG")

        Button(self.top1, text="Перейти к заданиям", command=lambda: [self.top1.destroy(), self.stage1_quest()]).pack(anchor=S)
        Label(self.top1, image=self.image).pack(anchor=CENTER)

    def stage1_quest(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        Button(self.top1, text="Вернуться в комнату", command=lambda: [self.stop_stage_top2stage(), self.top1.destroy()], bg="green").pack(anchor=S)

        self.image = PhotoImage(file=r"resourses/3этап/Задания.png")
        Label(self.top1, image=self.image).pack(anchor=CENTER)

    def stop_stage_top2stage(self):
        Button(self.top_win1, text="Завершить первый этап", bg="green", command=self.top_win1.destroy).place(rely=.93, relx=.4)

        self.stage2 = Button(self.root, text="2 Этап", width=15, height=2, bg="green", command=self.stage_2).place(rely=.43, relx=.45, )

    # Второй этап игры
    def stage_2(self):
        self.top_win2 = tkinter.Toplevel(width=800, height=600)
        self.top_win2.geometry((f"{600}x{600}+200+200"))
        self.top_win2.focus_set()
        self.top_win2.grab_set()

        Label(self.top_win2, text="Условные операторы", font=20).place(relx=.4)

        self.image = PhotoImage(file=r"resourses/stage2/комната.png")
        Label(self.top_win2, image=self.image).grid(row=0, column=0)

        Button(self.top_win2, text="if-else", width=10, height=1, command=lambda: [self.chapter1_stage2()]).place(rely=.65, relx=.02)
        Label(self.top_win2, text="Логические\n операции", bg="red").place(relx=.73, rely=.2)
        Label(self.top_win2, text="Вложеные \nи каскадные\n условия", bg="red").place(relx=.55, rely=.85)

    def chapter1_stage2(self):
        self.top2 = tkinter.Toplevel(width=800, height=600)
        self.top2.geometry((f"{1000}x{800}"))
        self.top2.resizable(False, False)
        self.top2.focus_set()
        self.top2.grab_set()
        self.image = PhotoImage(file=r"resourses/stage2/if-else/if1.PNG")
        Label(self.top2, image=self.image).place(rely=0, relx=.1)
        Button(self.top2, text="Вернуться назад", command=self.top2.destroy, bg='yellow').place(rely=.96, relx=.9)
        Button(self.top2, text="Далее", bg="green", command=lambda: [self.top2.destroy(), self.chapter11_stage2()]).place(rely=.92, relx=.9)

    def chapter11_stage2(self):
        self.top2 = tkinter.Toplevel(width=800, height=600)
        self.top2.geometry((f"{1000}x{800}"))
        self.top2.resizable(False, False)
        self.top2.focus_set()
        self.top2.grab_set()

        self.image = PhotoImage(file=r"resourses/stage2/if-else/if2.PNG")
        Label(self.top2, image=self.image).place(rely=0, relx=.1)
        Button(self.top2, text="Вернуться назад", command=self.top2.destroy, bg='yellow').place(rely=.96, relx=.9)
        Button(self.top2, text="Далее", bg="green", command=lambda: [self.top2.destroy(), self.chapter12_stage2()]).place(rely=.92, relx=.9)

    def chapter12_stage2(self):
        self.top2 = tkinter.Toplevel(width=800, height=600)
        self.top2.geometry((f"{1000}x{800}"))
        self.top2.resizable(False, False)
        self.top2.focus_set()
        self.top2.grab_set()
        self.image = PhotoImage(file=r"resourses/stage2/if-else/if3.PNG")
        Label(self.top2, image=self.image).place(rely=0, relx=.1)
        Button(self.top2, text="Завершить раздел", command=lambda: [self.top2.destroy()], bg='yellow').place(rely=.96, relx=.87)
        Button(self.top_win2, text="Логические\n операции", bg="green", command=self.chapter2_stage2).place(relx=.73, rely=.2)

    def chapter2_stage2(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy, bg='yellow').place(rely=.97, relx=.9)

        self.image = PhotoImage(file=r"resourses/stage2/Логические Операторы/and.png")
        Label(self.top1, image=self.image).place(rely=0, relx=.1)
        Button(self.top1, text="Далее", bg="green", command=lambda: [self.top1.destroy(), self.chapter21_stage2()]).place(rely=.92, relx=.9)

    def chapter21_stage2(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy, bg='yellow').place(rely=.97, relx=.9)

        self.image = PhotoImage(file=r"resourses/stage2/Логические Операторы/or.png")
        Label(self.top1, image=self.image).place(rely=0, relx=.1)
        Button(self.top1, text="Далее", bg="green", command=lambda: [self.top1.destroy(), self.chapter22_stage2()]).place(rely=.92, relx=.9)

    def chapter22_stage2(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy, bg='yellow').place(rely=.97, relx=.9)

        self.image = PhotoImage(file=r"resourses/stage2/Логические Операторы/not.png")
        Label(self.top1, image=self.image).place(rely=0, relx=.1)
        Button(self.top1, text="Далее", bg="green", command=lambda: [self.top1.destroy()]).place(rely=.92, relx=.9)

        Button(self.top_win2, text="Вложеные \nи каскадные\n условия", bg="green", command=self.chapter3_stage2).place(relx=.55, rely=.85)

    def chapter3_stage2(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        self.image = PhotoImage(file=r"resourses/stage2/каскад/какскад.png")
        Label(self.top1, image=self.image).place(rely=0, relx=.1)
        Button(self.top1, text="Вернуться назад", command=self.top1.destroy, bg='yellow').place(rely=.97, relx=.9)
        Button(self.top1, text="Перейти к заданиям", command=lambda: [self.top1.destroy(), self.stage2_quest()]).place(rely=.9, relx=.44)

    def stage2_quest(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{1000}"))
        self.top1.resizable(False, False)
        self.top1.focus_set()
        self.top1.grab_set()
        self.image = PhotoImage(file=r"resourses/stage2/Задачи/задачи.png")
        Label(self.top1, image=self.image).place(rely=0, relx=0)

        Button(self.top1, text="Вернуться в комнату", command=lambda: [self.top1.destroy(), self.stop_stage2_top3()]).place(rely=.86, relx=.45)

    def stop_stage2_top3(self):
        Button(self.top_win2, text="Завершить этап", command=self.top_win2.destroy, bg='green').place(rely=.5, relx=.45)
        Button(self.root, text="3 Этап", width=20, height=2, bg="green", command=self.stage_3).place(rely=.55, relx=.42)

    # Третий этап игры

    def stage_3(self):
        self.top_win3 = tkinter.Toplevel(width=800, height=600)
        self.top_win3.geometry((f"{600}x{600}+200+200"))
        self.top_win3.focus_set()
        self.top_win3.grab_set()

        Button(self.top_win3, text="Цикл for", command=self.chapterfor_stage3).place(rely=.9, relx=.1)
        Label(self.top_win3, text="Цикл while", bg="red").place(rely=.8, relx=.2)
        Label(self.top_win3, text="Вложенные циелы", bg="red").place(rely=.7, relx=.3)

    def chapterfor_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{900}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/for1.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chapterfor2_stage3()], bg="green").pack(anchor=S)

    def chapterfor2_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{1000}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/for2.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Завершить", bg="green", command=self.top1.destroy).pack(anchor=S)
        Button(self.top_win3, text="Цикл while", bg="green", command=self.chapterWhile1_stage3).place(rely=.8, relx=.2)

    def chapterWhile1_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{1000}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/while1.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chapterWhile2_stage3()], bg="green").pack(anchor=S)

    def chapterWhile2_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/while2.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chapterWhile3_stage3()], bg="green").pack(anchor=S)

    def chapterWhile3_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/while3.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Завершить", command=lambda: [self.top1.destroy()], bg="green").pack(anchor=S)
        Button(self.top_win3, text="Вложенные циклы", bg="green", command=self.chaptervloz_stage3).place(rely=.7, relx=.3)

    def chaptervloz_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{900}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/vloz1.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Далее", command=lambda: [self.top1.destroy(), self.chaptervloz2_stage3()], bg="green").pack(anchor=S)

    def chaptervloz2_stage3(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{900}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/vloz2.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Перейти к заданиям", command=lambda: [self.top1.destroy(), self.stage3_quest()], bg="green").pack(anchor=S)

    def stage3_quest(self):
        self.top1 = tkinter.Toplevel(width=800, height=600)
        self.top1.geometry((f"{1000}x{800}"))
        self.top1.focus_set()
        self.top1.grab_set()

        self.image = PhotoImage(file="resourses/stage3/quest_stage3.PNG")
        Label(self.top1, image=self.image).pack(anchor=CENTER)
        Button(self.top1, text="Завершить этап", command=lambda: [self.top1.destroy()], bg="green").pack(anchor=S)
        Button(self.top_win3, text="Завершить этап", command=lambda: [self.top_win3.destroy()], bg="green").pack(anchor=S)
        Button(self.root, text="4 Этап", width=25, height=2, bg="green", command=self.stage_4).place(rely=.68, relx=.40)

    # Четвертый этап игры
    def stage_4(self):
        self.top_win4 = tkinter.Toplevel(width=800, height=600)
        self.top_win4.geometry((f"{600}x{600}+200+200"))
        self.top_win4.focus_set()
        self.top_win4.grab_set()

        Label(self.top_win4, text="Списки", bg="pink").pack(anchor=S)

        Button(self.top_win4, text="Введение в списки", bg="green", command=self.Introduction1_stage4).place(relx=.8, rely=.1)

        Label(self.top_win4, text="Основы работы", bg="red").place(relx=.2, rely=.6)

    def Introduction1_stage4(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{1000}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/in1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="yellow", command=lambda: [self.top.destroy(), self.Introduction2_stage4()]).place(relx=.9, rely=.95)

    def Introduction2_stage4(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{1000}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/in2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Завершть", bg="yellow", command=self.top.destroy).place(relx=.8, rely=.9)
        Button(self.top_win4, text="Основы работы", bg="green", command=self.basics1_list).place(relx=.2, rely=.6)

    def basics1_list(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{1000}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/basics/basics1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="yellow", command=lambda: [self.top.destroy(), self.basics2_list()]).place(relx=.9, rely=.95)

    def basics2_list(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/basics/basics2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="yellow", command=lambda: [self.top.destroy(), self.basics3_list()]).place(relx=.9, rely=.95)

    def basics3_list(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/basics/basics3.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="yellow", command=lambda: [self.top.destroy(), self.basics4_list()]).place(relx=.9, rely=.95)

    def basics4_list(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{900}x{1000}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/basics/basics4.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="yellow", command=lambda: [self.top.destroy(), self.basics5_list()]).place(relx=.9, rely=.95)

    def basics5_list(self):
        self.top = tkinter.Toplevel(width=800, height=600)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()

        self.image = PhotoImage(file="resourses/stage4/basics/basics5.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Завершить", bg="yellow", command=lambda: [self.top.destroy()]).place(relx=.9, rely=.95)
        Button(self.top_win4, text="Методы списков", bg="green", command=self.Func_list_main).place(relx=.5, rely=.7)

    def Func_list_main(self):
        self.top_main = tkinter.Toplevel(width=800, height=600)
        self.top_main.geometry((f"{800}x{600}+200+200"))
        self.top_main.focus_set()
        self.top_main.grab_set()

        Button(self.top_main, text="Методы списков 1 часть", bg="green", command=self.Func_list1).pack(pady=20)
        Button(self.top_main, text="Методы строк", bg="green", command=self.Func_str).pack(pady=100)
        Button(self.top_main, text="Методы списков 2 часть", bg="green", command=self.Func_list_stage2).pack(pady=100)

    def Func_list1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/1stage/func1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list2()]).place(relx=.9, rely=.9)

    def Func_list2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/1stage/func2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list3()]).place(relx=.9, rely=.9)

    def Func_list3(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{750}x{700}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/1stage/func3.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Вернуться в лобби", bg="green", command=self.top.destroy).place(relx=.7, rely=.9)

    def Func_str(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{900}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funcstr/funcstr1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_str2()]).place(relx=.9, rely=.95)

    def Func_str2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funcstr/funcstr2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Вернуться в лобби", bg="green", command=lambda: [self.top.destroy()]).place(relx=.9, rely=.95)

    def Func_list_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/insert.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list2_stage2()]).place(relx=.9, rely=.95)

    def Func_list2_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/index.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list3_stage2()]).place(relx=.9, rely=.95)

    def Func_list3_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{600}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/remove.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list4_stage2()]).place(relx=.9, rely=.95)

    def Func_list4_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/pop.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list5_stage2()]).place(relx=.9, rely=.95)

    def Func_list5_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{700}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/count.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_list6_stage2()]).place(relx=.9, rely=.95)

    def Func_list6_stage2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{700}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/funclist/2stage/clear.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy()]).place(relx=.9, rely=.95)

        Button(self.top_main, text="Перейти к заданиям", width=50, height=20, bg="yellow",
               command=lambda: [self.top.destroy(), self.quest_stage4()]).pack(side=BOTTOM)

    def quest_stage4(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{700}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/quest/q1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.quest2_stage4()]).place(relx=.9, rely=.95)

    def quest2_stage4(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{900}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.image = PhotoImage(file="resourses/stage4/quest/q2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.top_main.destroy()]).place(relx=.9, rely=.95)
        Button(self.top_win4, text="Завершить этап", width=10, height=5, bg="yellow", command=self.top_win4.destroy).pack(side=BOTTOM)
        Button(self.root, text="5 Этап", width=30, height=3, bg="green", command=self.stage_5).place(rely=.86, relx=.38)

    # Пятый этап игры
    def stage_5(self):
        self.top_win5 = tkinter.Toplevel(width=800, height=600)
        self.top_win5.geometry((f"{600}x{700}+200+200"))
        self.top_win5.focus_set()
        self.top_win5.grab_set()

        Button(self.top_win5, text="Функции", bg="green", command=self.Func1, width=20,height=10).pack(side=TOP, pady=100)
        Button(self.top_win5, text="Локальные \nи\n глобальные переменные", command=self.main_var, width=20, height=10, bg="blue", fg="white").pack(side=LEFT, pady=100)
        Button(self.top_win5, text="Функции \nс\n возвратом значений",  command=self.Func_refound_main, width=20, height=10, bg="pink").pack(side=RIGHT, pady=100)

    def Func1(self):
        self.top_func = tkinter.Toplevel(width=800, height=800)
        self.top_func.geometry((f"{800}x{700}+200+200"))
        self.top_func.focus_set()
        self.top_func.grab_set()

        Button(self.top_func, text="Функции без параметров", bg="blue", fg="#0F0", width=30, height=10, command=self.Func_dont_par1).pack(side=TOP,
                                                                                                                                     pady=100)
        Button(self.top_func, text="Функции с параметрами", bg="yellow", width=30, height=10, command=self.Func_par1).pack(side=TOP, pady=10)
        Button(self.top_func, text="Выйти", bg="red", command=self.top_func.destroy).place(rely=.96, relx=.48)

    def Func_dont_par1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{930}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False,False)

        self.image=PhotoImage(file="resourses/stage5/funcdontpar/funcdont1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda :[self.top.destroy(),self.Func_dont_par2()]).pack(anchor=SE)
        Button(self.top, text="Выйти", bg="red", command=self.top.destroy).pack(anchor=SE)

    def Func_dont_par2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcdontpar/funcdont2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green",command=lambda :[self.top.destroy(),self.Func_dont_par3()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_dont_par3(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcdontpar/funcdont3.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_par1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{950}"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcpar/funcpar.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_par2()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_par2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{950}"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcpar/funcpar2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_par3()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_par3(self):

        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{900}"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcpar/funcpar3.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)

        Button(self.top, text="Завершить", bg="Yellow", command=self.top.destroy).pack(anchor=SE)
        Button(self.top_func, text="Выйти", bg="green", command=self.top_func.destroy).place(rely=.96, relx=.48)

    def main_var(self):
        self.top_var = tkinter.Toplevel(width=800, height=800)
        self.top_var.geometry((f"{600}x{600}"))
        self.top_var.focus_set()
        self.top_var.grab_set()
        self.top_var.resizable(False, False)

        Button(self.top_var, text="Локальные переменные", bg="pink",width=30, height=10, command=self.local_variables).pack(side=TOP, pady=100)
        Button(self.top_var, text="Глобальные переменные",bg="purple", fg="white", width=30, height=10, command=self.global_variables).pack(side=TOP, pady=10)
        Button(self.top_var, text="Выйти", bg="red", command=self.top_var.destroy).place(rely=.96, relx=.46)



    def local_variables(self):
        self.top_loc_var = tkinter.Toplevel(width=800, height=800)
        self.top_loc_var.geometry((f"{750}x{880}"))
        self.top_loc_var.focus_set()
        self.top_loc_var.grab_set()
        self.top_loc_var.resizable(False, False)

        self.image = PhotoImage(file="resourses/stage5/var/localvar/lovar1.PNG")
        Label(self.top_loc_var, image=self.image).pack(anchor=CENTER)
        Button(self.top_loc_var, text="Далее", bg="green", command= lambda:[self.top_loc_var.destroy(),self.local_variables2() ]).pack(anchor=SE)
        Button(self.top_loc_var, text="Назад", bg="yellow",command=self.top_loc_var.destroy).pack(anchor=SE)

    def local_variables2(self):
        self.top_loc_var2 = tkinter.Toplevel(width=800, height=800)
        self.top_loc_var2.geometry((f"{800}x{700}"))
        self.top_loc_var2.focus_set()
        self.top_loc_var2.grab_set()
        self.top_loc_var2.resizable(False, False)

        self.image = PhotoImage(file="resourses/stage5/var/localvar/locvar2.PNG")
        Label(self.top_loc_var2, image=self.image).pack(anchor=CENTER)
        Button(self.top_loc_var2, text="Завершить", bg="yellow", command=self.top_loc_var2.destroy).pack(anchor=SE)






    def global_variables(self):
        self.top_global_var = tkinter.Toplevel(width=800, height=800)
        self.top_global_var.geometry((f"{800}x{800}"))
        self.top_global_var.focus_set()
        self.top_global_var.grab_set()
        self.top_global_var.resizable(False, False)

        self.image = PhotoImage(file="resourses/stage5/var/globalvar/gvar1.PNG")
        Label(self.top_global_var, image=self.image).pack(anchor=CENTER)

        Button(self.top_global_var, text="Далее", bg="green", command=lambda: [self.top_global_var.destroy(), self.global_variables2()]).pack(anchor=SE)
        Button(self.top_global_var, text="Назад", bg="yellow", command=self.top_global_var.destroy).pack(anchor=SE)

    def global_variables2(self):
        self.top_global_var2 = tkinter.Toplevel(width=800, height=800)
        self.top_global_var2 .geometry((f"{800}x{900}"))
        self.top_global_var2 .focus_set()
        self.top_global_var2 .grab_set()
        self.top_global_var2 .resizable(False, False)

        self.image = PhotoImage(file="resourses/stage5/var/globalvar/gvar2.PNG")
        Label(self.top_global_var2 , image=self.image).pack(anchor=CENTER)
        Button(self.top_global_var2 , text="Завершить", bg="green", command=self.top_global_var2 .destroy).pack(anchor=SE)
        Button(self.top_var, text="Выйти", bg="green", command=self.top_var.destroy).place(rely=.96, relx=.46)

    def Func_refound_main(self):
        self.top_refound_main = tkinter.Toplevel(width=800, height=800)
        self.top_refound_main.geometry((f"{800}x{800}"))
        self.top_refound_main.focus_set()
        self.top_refound_main.grab_set()
        self.top_refound_main.resizable(False, False)

        Button(self.top_refound_main, text="Функции \nс\n возвратом значений \nчасть 1", bg="pink", width=30, height=10,command=self.Func_refound_ch1)\
            .pack(side=TOP, pady=50)
        Button(self.top_refound_main, text="Функции \nс\n возвратом значений \nчасть 2", bg="blue", width=30, height=10, fg="white",command=self.Func_refound_ch2)\
            .pack(side=LEFT, pady=50)
        Button(self.top_refound_main, text="Функции \nс\n возвратом значений \nчасть 3", bg="orange", width=30, height=10,command=self.Func_refound_ch3)\
            .pack(side=RIGHT, pady=50)
        #Button(self.top_refound_main, text="Сортировки", bg="green", width=30, height=10, fg="white", command=self.Func_refound_sort)\
            #.pack(anchor=CENTER, pady=20)
        Button(self.top_refound_main, text="Выйти", bg="red", command=self.top_refound_main.destroy, width=10, height=3)\
            .place(rely=.94, relx=.46)



    def Func_refound_ch1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{900}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch1/ref1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_refound2_ch1()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_refound2_ch1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{900}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch1/ref2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_refound3_ch1()]).pack(anchor=SE)
        Button(self.top, text="назад", bg="Yellow", command=self.top.destroy).pack(anchor=SE)

    def Func_refound3_ch1(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{700}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch1/ref3.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy()])\
                                                                                                                                .pack(anchor=SE)
        Button(self.top, text="Завершить", bg="Yellow", command=self.top.destroy)\
                                                                                                                             .pack(anchor=SE)

    def Func_refound_ch2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{610}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch2/ref1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_refound2_ch2()]) \
            .pack(anchor=SE)
        Button(self.top, text="Назад", bg="Yellow", command=self.top.destroy) \
            .pack(anchor=SE)

    def Func_refound2_ch2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{640}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch2/ref2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy()]) \
            .pack(anchor=SE)
        Button(self.top, text="Завершить", bg="Yellow", command=self.top.destroy) \
            .pack(anchor=SE)

    def Func_refound_ch3(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{800}x{800}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch3/ref1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)
        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_refound2_ch3()]) \
            .pack(anchor=SE)
        Button(self.top, text="Назад", bg="Yellow", command=self.top.destroy) \
            .pack(anchor=SE)

    def Func_refound2_ch3(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{700}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/ch3/ref2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)

        Button(self.top, text="Завершить", bg="Yellow", command=self.top.destroy) \
            .pack(anchor=SE)
        Button(self.top_refound_main, text="Сортировки", bg="green", width=30, height=10, fg="white", command=self.Func_refound_sort) \
            .pack(anchor=CENTER, pady=20)
    def Func_refound_sort(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{700}x{600}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/sort/sort1.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)

        Button(self.top, text="Далее", bg="green", command=lambda: [self.top.destroy(), self.Func_refound_sort2()]) \
            .pack(anchor=SE)
        Button(self.top, text="Назад", bg="Yellow", command=self.top.destroy) \
            .pack(anchor=SE)

    def Func_refound_sort2(self):
        self.top = tkinter.Toplevel(width=800, height=800)
        self.top.geometry((f"{700}x{650}+200+200"))
        self.top.focus_set()
        self.top.grab_set()
        self.top.resizable(False, False)
        self.image = PhotoImage(file="resourses/stage5/funcrefoubd/sort/sort2.PNG")
        Label(self.top, image=self.image).pack(anchor=CENTER)


        Button(self.top, text="Завершить этап", bg="green", command=self.top.destroy) \
            .pack(anchor=SE)
        Button(self.top_refound_main, text="Завершить игру", bg="green", command=lambda :[self.top_refound_main.destroy(),self.top_win5.destroy()] ,width=10, height=3) \
            .place(rely=.94, relx=.46)




if __name__ == "__main__":
    window = Window(800, 600, "Python Quest")

    window.draw_widjets()

    window.run()
