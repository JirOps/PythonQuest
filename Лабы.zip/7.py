try:
    f = open(name.txt, w)
except:
    print('Файл уже существует')