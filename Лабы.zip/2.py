a = int(input())
print(3-2.6**(a*3) - 30.3**(a*2))