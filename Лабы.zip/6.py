numbers = []

for _ in range:
    numbers.append(int(input()))
    
a = int(input())
numbers = numers[a:]+numbers[:a]


print(numbers)
