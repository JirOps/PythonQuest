a = int(input())
b = int(input())
c = int(input())
print(c == a+b)